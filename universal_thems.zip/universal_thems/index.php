<?php 
get_header(); ?>
<h1>привет мир</h1>
<?php
get_footer();